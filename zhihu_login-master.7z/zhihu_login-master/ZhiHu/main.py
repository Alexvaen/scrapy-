from scrapy import cmdline

__author__ = "Alex"
__date__ = "2019/8/9 下午12:31"

cmdline.execute("scrapy crawl zhihu_login".split())

